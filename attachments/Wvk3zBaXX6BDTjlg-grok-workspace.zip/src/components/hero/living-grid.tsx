import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

type Node = {
  x: number;
  y: number;
  ox: number;
  oy: number;
  vx: number;
  vy: number;
  seed: number;
  col: number;
  row: number;
};

type Edge = { a: number; b: number; spine: boolean };

const SQRT3 = Math.sqrt(3);
const INK = { r: 243, g: 243, b: 240 };

function hexPixel(col: number, row: number, size: number) {
  const x = size * SQRT3 * (col + 0.5 * (row & 1));
  const y = size * 1.5 * row;
  return { x, y };
}

function neighbors(col: number, row: number) {
  const odd = row & 1;
  return odd
    ? [
        [col + 1, row],
        [col - 1, row],
        [col, row - 1],
        [col + 1, row - 1],
        [col, row + 1],
        [col + 1, row + 1],
      ]
    : [
        [col + 1, row],
        [col - 1, row],
        [col - 1, row - 1],
        [col, row - 1],
        [col - 1, row + 1],
        [col, row + 1],
      ];
}

function hexRing(cx: number, cy: number, radius: number) {
  const pts: { x: number; y: number }[] = [];
  for (let i = 0; i < 6; i++) {
    const a = (Math.PI / 180) * (60 * i - 30);
    pts.push({ x: cx + Math.cos(a) * radius, y: cy + Math.sin(a) * radius });
  }
  return pts;
}

function strokeHex(
  ctx: CanvasRenderingContext2D,
  pts: { x: number; y: number }[],
  progress: number,
) {
  const p = Math.max(0, Math.min(1, progress));
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  const edges = 6;
  const drawn = p * edges;
  for (let i = 1; i <= edges; i++) {
    const t = Math.max(0, Math.min(1, drawn - (i - 1)));
    if (t <= 0) break;
    const a = pts[i - 1];
    const b = pts[i % 6];
    ctx.lineTo(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
  }
  if (p >= 1) ctx.closePath();
  ctx.stroke();
}

export function LivingGrid({ className }: { className?: string }) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const coarse = window.matchMedia("(pointer: coarse)").matches;

    let width = 0;
    let height = 0;
    let dpr = 1;
    let nodes: Node[] = [];
    let edges: Edge[] = [];
    let markOuter: { x: number; y: number }[] = [];
    let markInner: { x: number; y: number }[] = [];
    let markMid: { x: number; y: number }[] = [];
    let raf = 0;
    let visible = true;
    let last = performance.now();
    const pointer = { x: 0, y: 0, active: false, tx: 0, ty: 0 };
    let cx = 0;
    let cy = 0;
    let markR = 0;

    function rebuild() {
      const rect = wrap!.getBoundingClientRect();
      width = Math.max(1, Math.floor(rect.width));
      height = Math.max(1, Math.floor(rect.height));
      dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas!.width = Math.floor(width * dpr);
      canvas!.height = Math.floor(height * dpr);
      canvas!.style.width = `${width}px`;
      canvas!.style.height = `${height}px`;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);

      const size = coarse
        ? Math.max(40, Math.min(52, width / 8))
        : Math.max(28, Math.min(38, width / 14));
      const colCount = Math.ceil(width / (size * SQRT3)) + 2;
      const rowCount = Math.ceil(height / (size * 1.5)) + 2;
      const ox = (width - (colCount - 1) * size * SQRT3) / 2;
      const oy = (height - (rowCount - 1) * size * 1.5) / 2;

      const index = new Map<string, number>();
      nodes = [];
      for (let row = 0; row < rowCount; row++) {
        for (let col = 0; col < colCount; col++) {
          const p = hexPixel(col, row, size);
          const x = p.x + ox;
          const y = p.y + oy;
          if (x < -size || y < -size || x > width + size || y > height + size) {
            continue;
          }
          index.set(`${col},${row}`, nodes.length);
          nodes.push({
            x,
            y,
            ox: x,
            oy: y,
            vx: 0,
            vy: 0,
            seed: (col * 13 + row * 7) * 0.37,
            col,
            row,
          });
        }
      }

      edges = [];
      const seen = new Set<string>();
      for (const n of nodes) {
        for (const [nc, nr] of neighbors(n.col, n.row)) {
          const j = index.get(`${nc},${nr}`);
          if (j == null) continue;
          const i = index.get(`${n.col},${n.row}`);
          if (i == null) continue;
          const key = i < j ? `${i}-${j}` : `${j}-${i}`;
          if (seen.has(key)) continue;
          seen.add(key);
          const spine = (i + j) % 7 === 0;
          edges.push({ a: i, b: j, spine });
        }
      }

      cx = width * 0.52;
      cy = height * 0.5;
      markR = Math.min(width, height) * (coarse ? 0.28 : 0.24);
      markOuter = hexRing(cx, cy, markR);
      markMid = hexRing(cx, cy, markR * 0.72);
      markInner = hexRing(cx, cy, markR * 0.46);
    }

    function drawMark(progress: number, fillAlpha: number) {
      ctx!.lineJoin = "miter";
      ctx!.lineCap = "butt";

      ctx!.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},${0.55 * Math.min(1, progress)})`;
      ctx!.lineWidth = 1.35;
      strokeHex(ctx!, markOuter, progress);

      ctx!.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},${0.28 * Math.min(1, progress)})`;
      ctx!.lineWidth = 1;
      strokeHex(ctx!, markMid, progress - 0.12);

      ctx!.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},${0.7 * Math.min(1, progress - 0.2)})`;
      ctx!.lineWidth = 1.2;
      strokeHex(ctx!, markInner, progress - 0.22);

      if (progress > 0.55 && fillAlpha > 0) {
        ctx!.save();
        ctx!.globalAlpha = fillAlpha;
        ctx!.beginPath();
        ctx!.moveTo(markOuter[0].x, markOuter[0].y);
        for (let i = 1; i < 6; i++) ctx!.lineTo(markOuter[i].x, markOuter[i].y);
        ctx!.closePath();
        ctx!.moveTo(markInner[0].x, markInner[0].y);
        for (let i = 5; i >= 0; i--) ctx!.lineTo(markInner[i].x, markInner[i].y);
        ctx!.closePath();
        ctx!.fillStyle = `rgba(${INK.r},${INK.g},${INK.b},0.045)`;
        ctx!.fill("evenodd");
        ctx!.restore();
      }

      if (progress > 0.85) {
        ctx!.fillStyle = `rgba(${INK.r},${INK.g},${INK.b},0.85)`;
        ctx!.fillRect(cx - 2, cy - 2, 4, 4);
      }
    }

    function drawStatic() {
      ctx!.clearRect(0, 0, width, height);
      ctx!.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},0.09)`;
      ctx!.lineWidth = 1;
      for (const e of edges) {
        if (!e.spine && (e.a + e.b) % 4 !== 0) continue;
        const a = nodes[e.a];
        const b = nodes[e.b];
        ctx!.beginPath();
        ctx!.moveTo(a.x, a.y);
        ctx!.lineTo(b.x, b.y);
        ctx!.stroke();
      }
      drawMark(1, 1);
      ctx!.fillStyle = `rgba(${INK.r},${INK.g},${INK.b},0.35)`;
      for (const n of nodes) {
        if ((n.col + n.row) % 3 !== 0) continue;
        ctx!.fillRect(n.x - 1, n.y - 1, 2, 2);
      }
    }

    function step(now: number) {
      const dt = Math.min(32, now - last);
      last = now;
      const t = now * 0.001;
      const assemble = Math.min(1, t / 2.4);

      pointer.x += (pointer.tx - pointer.x) * 0.16;
      pointer.y += (pointer.ty - pointer.y) * 0.16;

      const radius = coarse ? 0 : 140;
      const radius2 = radius * radius;

      for (const n of nodes) {
        const idleX = Math.sin(t * 0.22 + n.seed) * 0.4;
        const idleY = Math.cos(t * 0.18 + n.seed * 1.3) * 0.4;
        let tx = n.ox + idleX;
        let ty = n.oy + idleY;
        if (pointer.active && radius > 0) {
          const dx = n.ox - pointer.x;
          const dy = n.oy - pointer.y;
          const d2 = dx * dx + dy * dy;
          if (d2 < radius2 && d2 > 0.25) {
            const d = Math.sqrt(d2);
            const f = (1 - d / radius) ** 2;
            tx += (dx / d) * f * 14;
            ty += (dy / d) * f * 14;
          }
        }
        n.vx = (n.vx + (tx - n.x) * 0.1) * 0.8;
        n.vy = (n.vy + (ty - n.y) * 0.1) * 0.8;
        n.x += n.vx * (dt / 16.67);
        n.y += n.vy * (dt / 16.67);
      }

      ctx!.clearRect(0, 0, width, height);
      ctx!.lineJoin = "miter";
      ctx!.lineCap = "butt";

      for (const e of edges) {
        const a = nodes[e.a];
        const b = nodes[e.b];
        const mx = (a.x + b.x) * 0.5;
        const my = (a.y + b.y) * 0.5;
        let prox = 0;
        if (pointer.active && radius > 0) {
          const d = Math.hypot(mx - pointer.x, my - pointer.y);
          prox = Math.max(0, 1 - d / radius);
        }
        const keep = e.spine || (e.a + e.b) % 4 === 0;
        if (!keep && prox < 0.14) continue;
        const alpha = keep ? 0.08 + prox * 0.34 : 0.03 + prox * 0.4;
        ctx!.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},${alpha})`;
        ctx!.lineWidth = e.spine ? 1.1 : 1;
        ctx!.beginPath();
        ctx!.moveTo(a.x, a.y);
        ctx!.lineTo(b.x, b.y);
        ctx!.stroke();
      }

      const breath = 0.55 + 0.45 * Math.sin(t * 0.35);
      drawMark(assemble, breath);

      for (const n of nodes) {
        const life = 0.5 + 0.5 * Math.sin(t * 0.32 + n.seed);
        if (life < 0.18 && !pointer.active) continue;
        let prox = 0;
        if (pointer.active && radius > 0) {
          const d = Math.hypot(n.x - pointer.x, n.y - pointer.y);
          prox = Math.max(0, 1 - d / radius);
        }
        const s = 0.9 + prox * 1.6 + life * 0.4;
        const alpha = 0.16 + life * 0.22 + prox * 0.5;
        ctx!.fillStyle = `rgba(${INK.r},${INK.g},${INK.b},${alpha})`;
        ctx!.fillRect(n.x - s, n.y - s, s * 2, s * 2);
      }

      if (pointer.active && !coarse) {
        ctx!.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},0.45)`;
        ctx!.lineWidth = 1;
        ctx!.beginPath();
        ctx!.moveTo(pointer.x - 7, pointer.y);
        ctx!.lineTo(pointer.x + 7, pointer.y);
        ctx!.moveTo(pointer.x, pointer.y - 7);
        ctx!.lineTo(pointer.x, pointer.y + 7);
        ctx!.stroke();
      }
    }

    function loop(now: number) {
      if (!visible) return;
      if (reduced) {
        drawStatic();
        return;
      }
      step(now);
      raf = requestAnimationFrame(loop);
    }

    function onPointer(e: PointerEvent) {
      if (coarse) return;
      const rect = canvas!.getBoundingClientRect();
      pointer.tx = e.clientX - rect.left;
      pointer.ty = e.clientY - rect.top;
      pointer.active = true;
    }
    function onLeave() {
      pointer.active = false;
    }

    rebuild();
    if (reduced) drawStatic();
    else raf = requestAnimationFrame(loop);

    const ro = new ResizeObserver(() => {
      rebuild();
      if (reduced) drawStatic();
    });
    ro.observe(wrap);

    const io = new IntersectionObserver(([entry]) => {
      visible = Boolean(entry?.isIntersecting);
      if (visible && !reduced) {
        last = performance.now();
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(loop);
      } else {
        cancelAnimationFrame(raf);
      }
    });
    io.observe(wrap);

    canvas.addEventListener("pointermove", onPointer, { passive: true });
    canvas.addEventListener("pointerdown", onPointer, { passive: true });
    canvas.addEventListener("pointerleave", onLeave);
    canvas.addEventListener("pointercancel", onLeave);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      canvas.removeEventListener("pointermove", onPointer);
      canvas.removeEventListener("pointerdown", onPointer);
      canvas.removeEventListener("pointerleave", onLeave);
      canvas.removeEventListener("pointercancel", onLeave);
    };
  }, []);

  return (
    <div
      ref={wrapRef}
      className={cn("relative h-full w-full", className)}
      aria-hidden
    >
      <canvas
        ref={canvasRef}
        className="relative block h-full w-full touch-none"
      />
    </div>
  );
}
