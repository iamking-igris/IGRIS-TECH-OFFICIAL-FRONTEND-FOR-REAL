import { LivingGrid } from "@/components/hero/living-grid";
import { ButtonLink } from "@/components/ui/button-link";

export function HomeHero() {
  return (
    <section className="relative overflow-hidden border-b border-hairline">
      <div className="pointer-events-none absolute inset-0 hex-grid opacity-40 md:opacity-20" />

      <div className="relative mx-auto grid max-w-[1440px] items-end gap-10 px-5 pb-16 pt-24 sm:px-8 md:min-h-[100dvh] md:grid-cols-12 md:items-center md:gap-8 md:pb-20 md:pt-28 lg:px-12 xl:px-16">
        <div className="md:col-span-6 lg:col-span-6">
          <p className="label-tech hero-rise mb-7">IGRIS / 00</p>
          <h1
            className="hero-rise font-display text-[clamp(2.6rem,8vw,6.8rem)] font-semibold leading-[0.92] tracking-[-0.045em] text-ink"
            style={{ animationDelay: "80ms" }}
          >
            We build
            <br />
            what’s next.
          </h1>
          <p
            className="hero-rise mt-7 max-w-md text-base leading-relaxed text-quiet md:mt-8 md:text-lg"
            style={{ animationDelay: "160ms" }}
          >
            IGRIS Tech builds digital products, websites, software, and
            intelligent solutions for individuals, brands, and businesses.
          </p>
          <div
            className="hero-rise mt-9 flex flex-wrap items-center gap-3 md:mt-10 md:gap-4"
            style={{ animationDelay: "240ms" }}
          >
            <ButtonLink to="/contact" variant="primary">
              Start a Project
            </ButtonLink>
            <ButtonLink to="/work" variant="ghost">
              Explore Our Work
            </ButtonLink>
          </div>
        </div>

        <div className="relative h-[220px] sm:h-[280px] md:col-span-6 md:h-[min(68vh,620px)]">
          <LivingGrid />
          <p className="pointer-events-none absolute bottom-2 right-0 font-mono text-[10px] tracking-[0.18em] text-faint">
            SYSTEM / GRID
          </p>
        </div>
      </div>
    </section>
  );
}
