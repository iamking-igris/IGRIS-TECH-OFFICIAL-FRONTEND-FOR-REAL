import { createServerFn } from "@tanstack/react-start";

export const REVIEW_SERVICES = [
  "Web Development",
  "Software Development",
  "AI Solutions",
  "Automation",
  "Other",
] as const;

export type ReviewInput = {
  clientName: string;
  company: string;
  role: string;
  rating: number;
  content: string;
  project: string;
  website: string;
};

function trim(value: unknown) {
  return String(value ?? "").trim();
}

export const submitReview = createServerFn({ method: "POST" })
  .validator((raw: ReviewInput) => {
    const clientName = trim(raw.clientName);
    const company = trim(raw.company);
    const role = trim(raw.role);
    const content = trim(raw.content);
    const project = trim(raw.project);
    const website = trim(raw.website);
    const rating = Number(raw.rating);

    if (!clientName) throw new Error("Name is required.");
    if (!content) throw new Error("A review needs some words.");
    if (content.length < 20) {
      throw new Error("Please write a little more — at least a couple of sentences.");
    }
    if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
      throw new Error("Choose a rating from 1 to 5.");
    }

    return { clientName, company, role, rating, content, project, website };
  })
  .handler(async ({ data }) => {
    // Reviews enter a pending state. They are not published from this handler.
    // A future admin flow will approve or reject before anything appears publicly.
    void data;
    return {
      ok: true as const,
      status: "pending" as const,
      receivedAt: new Date().toISOString(),
    };
  });
