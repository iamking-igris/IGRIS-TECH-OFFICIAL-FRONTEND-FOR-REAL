import { FUTURE_PRODUCTS_NOTE } from "./seed";
import { useContentStore } from "./store";
import type { EcosystemInput, EcosystemProduct } from "./types";

export { FUTURE_PRODUCTS_NOTE };

/**
 * Ecosystem repository.
 * Mock implementation today. Later: GET/POST/PUT/DELETE /api/ecosystem.
 */
export const ecosystemService = {
  list(): EcosystemProduct[] {
    return [...useContentStore.getState().ecosystem].sort(
      (a, b) => a.order - b.order,
    );
  },
  published() {
    return ecosystemService.list().filter((p) => p.published);
  },
  getById(id: string) {
    return useContentStore.getState().ecosystem.find((p) => p.id === id) ?? null;
  },
  create(input: EcosystemInput) {
    return useContentStore.getState().createEcosystem(input);
  },
  update(id: string, input: EcosystemInput) {
    return useContentStore.getState().updateEcosystem(id, input);
  },
  delete(id: string) {
    useContentStore.getState().deleteEcosystem(id);
  },
};

export function useEcosystem() {
  return useContentStore((s) =>
    [...s.ecosystem].sort((a, b) => a.order - b.order),
  );
}

export function usePublishedEcosystem() {
  return useContentStore((s) =>
    [...s.ecosystem]
      .filter((p) => p.published)
      .sort((a, b) => a.order - b.order),
  );
}
