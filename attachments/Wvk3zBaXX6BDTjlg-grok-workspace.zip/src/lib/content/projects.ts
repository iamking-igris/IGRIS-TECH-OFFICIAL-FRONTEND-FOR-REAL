import { useContentStore } from "./store";
import type { Project, ProjectInput } from "./types";

/**
 * Project repository.
 * Mock implementation today. Swap the body of these functions for
 * GET/POST/PUT/DELETE /api/projects later — UI should keep calling this module.
 */
export const projectsService = {
  list(): Project[] {
    return useContentStore.getState().projects;
  },
  getById(id: string) {
    return useContentStore.getState().projects.find((p) => p.id === id) ?? null;
  },
  getBySlug(slug: string) {
    return useContentStore.getState().projects.find((p) => p.slug === slug) ?? null;
  },
  getPublishedBySlug(slug: string) {
    return (
      useContentStore
        .getState()
        .projects.find((p) => p.slug === slug && p.published) ?? null
    );
  },
  published() {
    return useContentStore.getState().projects.filter((p) => p.published);
  },
  featured() {
    return useContentStore
      .getState()
      .projects.filter((p) => p.published && p.featured);
  },
  related(slug: string) {
    return useContentStore
      .getState()
      .projects.filter((p) => p.published && p.slug !== slug);
  },
  create(input: ProjectInput) {
    return useContentStore.getState().createProject(input);
  },
  update(id: string, input: ProjectInput) {
    return useContentStore.getState().updateProject(id, input);
  },
  delete(id: string) {
    useContentStore.getState().deleteProject(id);
  },
  setPublished(id: string, published: boolean) {
    useContentStore.getState().setProjectPublished(id, published);
  },
};

export function useProjects() {
  return useContentStore((s) => s.projects);
}

export function usePublishedProjects() {
  return useContentStore((s) => s.projects.filter((p) => p.published));
}

export function useFeaturedProjects() {
  return useContentStore((s) =>
    s.projects.filter((p) => p.published && p.featured),
  );
}

export function useProjectBySlug(slug: string) {
  return useContentStore(
    (s) => s.projects.find((p) => p.slug === slug && p.published) ?? null,
  );
}

export function useRelatedProjects(slug: string) {
  return useContentStore((s) =>
    s.projects.filter((p) => p.published && p.slug !== slug),
  );
}
