export * from "./types";
export * from "./projects";
export * from "./ecosystem";
export * from "./reviews";
export * from "./contact";
export { useContentStore } from "./store";
export { FUTURE_PRODUCTS_NOTE } from "./seed";

import { useEffect, useState } from "react";
import { useContentStore } from "./store";

/** True after the mock store has rehydrated from localStorage (client). */
export function useContentHydrated() {
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const unsub = useContentStore.persist.onFinishHydration(() => {
      setHydrated(true);
    });
    if (useContentStore.persist.hasHydrated()) setHydrated(true);
    return unsub;
  }, []);

  return hydrated;
}
