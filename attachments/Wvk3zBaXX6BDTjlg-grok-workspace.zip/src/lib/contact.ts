import { createServerFn } from "@tanstack/react-start";

export const PROJECT_TYPES = [
  "Website",
  "Web Application",
  "Software",
  "AI Solution",
  "Automation",
  "Other",
] as const;

export const BUDGETS = [
  "Prefer not to say",
  "Under $2,000",
  "$2,000 – $8,000",
  "$8,000 – $20,000",
  "$20,000+",
] as const;

export const TIMELINES = [
  "As soon as possible",
  "1–2 months",
  "3–6 months",
  "Flexible",
] as const;

export const CONTACT_METHODS = ["Email", "Phone", "WhatsApp", "Other"] as const;

export type InquiryInput = {
  name: string;
  email: string;
  company: string;
  type: string;
  description: string;
  budget: string;
  timeline: string;
  website: string;
  contactMethod: string;
};

function trim(value: unknown) {
  return String(value ?? "").trim();
}

export const submitProjectInquiry = createServerFn({ method: "POST" })
  .validator((raw: InquiryInput) => {
    const name = trim(raw.name);
    const email = trim(raw.email);
    const type = trim(raw.type);
    const description = trim(raw.description);
    const company = trim(raw.company);
    const budget = trim(raw.budget);
    const timeline = trim(raw.timeline);
    const website = trim(raw.website);
    const contactMethod = trim(raw.contactMethod);

    if (!name) throw new Error("Name is required.");
    if (!email) throw new Error("Email is required.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      throw new Error("Enter a valid email address.");
    }
    if (!type) throw new Error("Project type is required.");
    if (!description) throw new Error("Project description is required.");
    if (website && !/^https?:\/\//i.test(website) && !website.includes(".")) {
      throw new Error("Enter a valid website or leave it blank.");
    }

    return {
      name,
      email,
      company,
      type,
      description,
      budget,
      timeline,
      website,
      contactMethod,
    };
  })
  .handler(async ({ data }) => {
    // Frontend is wired. A durable inbox / notification backend lands later.
    // Do not claim an email was sent.
    void data;
    return {
      ok: true as const,
      receivedAt: new Date().toISOString(),
    };
  });
