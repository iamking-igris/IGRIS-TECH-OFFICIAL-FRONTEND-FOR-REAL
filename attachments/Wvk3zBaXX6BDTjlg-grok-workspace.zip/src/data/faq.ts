export type FaqItem = {
  q: string;
  a: string;
};

export const servicesFaq: FaqItem[] = [
  {
    q: "How does a project start?",
    a: "You send a brief through Start a Project. We review what you want to build, ask the questions that are missing, and decide together whether IGRIS is the right fit — before anyone writes a line of production code.",
  },
  {
    q: "What do you typically build?",
    a: "Websites, web applications, custom software, AI features inside real products, and automation that removes repetitive work. If the job is a slide deck of buzzwords, it is not a fit.",
  },
  {
    q: "Do you work with early-stage ideas?",
    a: "Yes — if there is a real problem and a willingness to define the product. We do not need a 40-page spec. We do need honesty about users, constraints, and what “done” means.",
  },
  {
    q: "How is the IGRIS ecosystem related to client work?",
    a: "Client work is the core of the company. What we learn there becomes the foundation for products of our own. Those products will live on their own subdomains when they are ready — we do not announce them as live before they are.",
  },
  {
    q: "Where is the work published?",
    a: "Case studies go up when they are ready to share, with the client’s consent. We do not invent logos, metrics, or quotes to fill the Work page.",
  },
];
