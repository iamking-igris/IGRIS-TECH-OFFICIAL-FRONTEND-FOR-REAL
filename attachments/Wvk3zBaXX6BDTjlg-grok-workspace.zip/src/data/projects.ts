export type ProjectVisualId = "alpha" | "beta" | "gamma";

export type ProjectStatus = "live" | "in-preparation" | "archived";

export type Project = {
  id: string;
  slug: string;
  title: string;
  client: string;
  category: string;
  year: number | null;
  description: string;
  overview: string;
  challenge: string;
  objectives: string[];
  approach: string;
  design: string;
  development: string;
  keyDecisions: { title: string; text: string }[];
  results: string | null;
  services: string[];
  technologies: string[];
  gallery: { src: string; alt: string }[];
  testimonial: string | null;
  featuredImage: string | null;
  url: string | null;
  featured: boolean;
  published: boolean;
  placeholder: boolean;
  status: ProjectStatus;
  visual: ProjectVisualId;
  publishedAt: string | null;
  seoTitle: string;
  seoDescription: string;
};

/**
 * Structured slots for case studies.
 * These are not invented clients, results, or logos.
 * Replace fields when real work is ready to publish.
 */
export const projects: Project[] = [
  {
    id: "proj_web_platform",
    slug: "web-platform",
    title: "Web platform",
    client: "To be announced",
    category: "Web Development",
    year: null,
    description:
      "A web platform case study will be published here when the work is ready to share.",
    overview:
      "This entry is a structured placeholder. The case study format is in place so real work can be published without rebuilding the site.",
    challenge: "",
    objectives: [],
    approach: "",
    design: "",
    development: "",
    keyDecisions: [],
    results: null,
    services: ["web-development"],
    technologies: [],
    gallery: [],
    testimonial: null,
    featuredImage: null,
    url: null,
    featured: true,
    published: true,
    placeholder: true,
    status: "in-preparation",
    visual: "alpha",
    publishedAt: null,
    seoTitle: "Web platform — IGRIS Tech",
    seoDescription:
      "A web development case study from IGRIS Tech. Published when the work is ready to share.",
  },
  {
    id: "proj_custom_system",
    slug: "custom-system",
    title: "Custom system",
    client: "To be announced",
    category: "Software Development",
    year: null,
    description:
      "A custom software case study will be published here when the work is ready to share.",
    overview:
      "This entry is a structured placeholder. Challenge, approach, design, and development will be written from the actual project — not invented.",
    challenge: "",
    objectives: [],
    approach: "",
    design: "",
    development: "",
    keyDecisions: [],
    results: null,
    services: ["software-development"],
    technologies: [],
    gallery: [],
    testimonial: null,
    featuredImage: null,
    url: null,
    featured: true,
    published: true,
    placeholder: true,
    status: "in-preparation",
    visual: "beta",
    publishedAt: null,
    seoTitle: "Custom system — IGRIS Tech",
    seoDescription:
      "A software development case study from IGRIS Tech. Published when the work is ready to share.",
  },
  {
    id: "proj_intelligent_product",
    slug: "intelligent-product",
    title: "Intelligent product",
    client: "To be announced",
    category: "AI Solutions",
    year: null,
    description:
      "An intelligent product case study will be published here when the work is ready to share.",
    overview:
      "This entry is a structured placeholder. No metrics, quotes, or client names are fabricated to fill the page.",
    challenge: "",
    objectives: [],
    approach: "",
    design: "",
    development: "",
    keyDecisions: [],
    results: null,
    services: ["ai-solutions", "automation"],
    technologies: [],
    gallery: [],
    testimonial: null,
    featuredImage: null,
    url: null,
    featured: true,
    published: true,
    placeholder: true,
    status: "in-preparation",
    visual: "gamma",
    publishedAt: null,
    seoTitle: "Intelligent product — IGRIS Tech",
    seoDescription:
      "An AI and automation case study from IGRIS Tech. Published when the work is ready to share.",
  },
];

export function getProject(slug: string) {
  return projects.find((p) => p.slug === slug && p.published);
}

export function featuredProjects() {
  return projects.filter((p) => p.published && p.featured);
}

export function relatedProjects(slug: string) {
  return projects.filter((p) => p.published && p.slug !== slug);
}

export function publishedProjects() {
  return projects.filter((p) => p.published);
}
