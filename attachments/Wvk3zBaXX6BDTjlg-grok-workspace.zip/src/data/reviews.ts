export type ReviewStatus = "pending" | "approved" | "rejected";

export type Review = {
  id: string;
  clientName: string;
  company: string;
  role: string;
  rating: number;
  content: string;
  avatar: string | null;
  project: string | null;
  website: string | null;
  status: ReviewStatus;
  createdAt: string;
};

/**
 * Genuine testimonials only.
 * Public UI renders reviews with status === "approved".
 * Submissions enter as pending and stay off the public page until an admin approves them.
 * This array is the local/mock source — swap for an API later without changing the UI.
 */
export const reviews: Review[] = [];

export function publishedReviews() {
  return reviews.filter((r) => r.status === "approved");
}
