export type ProductStatus =
  | "Live"
  | "In development"
  | "Coming soon"
  | "Experimental";

export type EcosystemProduct = {
  id: string;
  name: string;
  slug: string;
  description: string;
  status: ProductStatus;
  category: string;
  logo: string | null;
  image: string | null;
  url: string | null;
  subdomain: string;
  featured: boolean;
  launchDate: string | null;
};

/**
 * Future public homes:
 * igristech.com
 * hosting.igristech.com
 * studio.igristech.com
 *
 * URLs are only set when a product is actually live.
 * Links are data-driven — do not hardcode live product URLs in copy.
 */
export const ecosystemProducts: EcosystemProduct[] = [
  {
    id: "eco_hosting",
    name: "IGRIS Hosting",
    slug: "hosting",
    description:
      "Infrastructure for the modern web. Product details will be published as the work lands.",
    status: "In development",
    category: "Infrastructure",
    logo: null,
    image: null,
    url: null,
    subdomain: "hosting.igristech.com",
    featured: true,
    launchDate: null,
  },
  {
    id: "eco_studio",
    name: "IGRIS Studio",
    slug: "studio",
    description:
      "A product in the IGRIS ecosystem. Scope and features will be published when they are real.",
    status: "In development",
    category: "Platform",
    logo: null,
    image: null,
    url: null,
    subdomain: "studio.igristech.com",
    featured: true,
    launchDate: null,
  },
];

export const futureProductsNote =
  "Further products will sit on their own subdomains under igristech.com when they are ready.";
