import { V as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Container, b as organizationJsonLd, v as breadcrumbJsonLd } from "./router-bk_2vDcH.mjs";
import { t as JsonLd } from "./json-ld-IR7igJk0.mjs";
import { t as CtaBand } from "./cta-band-DznpNq9S.mjs";
import { t as PageHeader } from "./page-header-DMPnpCTM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-BKn75TOC.js
var import_jsx_runtime = require_jsx_runtime();
/** Do not invent people. Empty until real profiles are provided. */
var teamMembers = [];
function TeamSection() {
	if (teamMembers.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-hairline",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-20 md:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-tech mb-4",
					children: "Team"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl font-semibold tracking-[-0.03em] md:text-5xl",
					children: "The people behind IGRIS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-12 grid gap-8 sm:grid-cols-2 md:grid-cols-3",
					children: teamMembers.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-hairline pt-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-xl font-semibold",
								children: member.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-quiet",
								children: member.role
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm leading-relaxed text-quiet",
								children: member.bio
							})
						]
					}, member.name))
				})
			]
		})
	});
}
var aboutChapters = [
	{
		index: "01",
		name: "Why IGRIS exists",
		text: "Digital products are too often assembled from templates, plugins, and tools that almost fit. IGRIS exists to build the actual thing — the site, the system, the product — with care and a long view."
	},
	{
		index: "02",
		name: "What IGRIS builds",
		text: "Websites, software, AI features, and automation. For individuals, brands, and businesses that need something useful in the world, not something that only looks finished in a screenshot."
	},
	{
		index: "03",
		name: "How IGRIS thinks",
		text: "Clarity over theatre. Build for use. Prefer a smaller surface that works to a large one that performs. Learn from every engagement, and do not claim what is not true."
	},
	{
		index: "04",
		name: "How IGRIS works",
		text: "Discover, define, design, build, ship. Close enough to the work to stay honest. No invented methodology, no forty-slide operating system — a sequence that gets a product into the world."
	},
	{
		index: "05",
		name: "The ecosystem",
		text: "IGRIS Tech is the parent company. Client work is how we stay close to real problems. In parallel we are building products of our own — IGRIS Hosting and IGRIS Studio among them — which will live on their own subdomains when they are ready."
	},
	{
		index: "06",
		name: "The future",
		text: "Keep building for clients. Ship our own products when they are real. Grow the experience and the foundation needed to make technology of our own — without pretending we are already a giant."
	}
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: organizationJsonLd() }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: breadcrumbJsonLd([{
				name: "Home",
				path: "/"
			}, {
				name: "About",
				path: "/about"
			}]) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "About",
				title: "A technology company that builds — for clients, and for itself.",
				description: "IGRIS Tech helps people and businesses turn ideas into digital products while building the experience and foundation needed to eventually create technology of its own."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-b border-hairline",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
					className: "py-16 md:py-24",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "grid gap-0",
						children: aboutChapters.map((chapter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid gap-4 border-t border-hairline py-10 last:border-b md:grid-cols-12 md:gap-10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs tracking-widest text-faint",
									children: chapter.index
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-2xl font-semibold tracking-[-0.03em] md:text-3xl",
									children: chapter.name
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-base leading-relaxed text-quiet md:col-span-7 md:text-lg",
								children: chapter.text
							})]
						}, chapter.index))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex flex-wrap gap-6 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/services",
								className: "underline-offset-4 hover:underline",
								children: "Services"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/work",
								className: "underline-offset-4 hover:underline",
								children: "Work"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/ecosystem",
								className: "underline-offset-4 hover:underline",
								children: "Ecosystem"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/contact",
								className: "underline-offset-4 hover:underline",
								children: "Contact"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {})
		]
	});
}
//#endregion
export { AboutPage as component };
