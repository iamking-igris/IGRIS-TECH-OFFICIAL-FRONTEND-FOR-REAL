import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reviews-zuTOSbb9.js
function trim(value) {
	return String(value ?? "").trim();
}
var submitReview_createServerFn_handler = createServerRpc({
	id: "6f1e727f1e2f85b90f64e628f5287e4b68ddf97606137625d3a83ca59cdd0f4b",
	name: "submitReview",
	filename: "src/lib/reviews.ts"
}, (opts) => submitReview.__executeServer(opts));
var submitReview = createServerFn({ method: "POST" }).validator((raw) => {
	const clientName = trim(raw.clientName);
	const company = trim(raw.company);
	const role = trim(raw.role);
	const content = trim(raw.content);
	const project = trim(raw.project);
	const website = trim(raw.website);
	const rating = Number(raw.rating);
	if (!clientName) throw new Error("Name is required.");
	if (!content) throw new Error("A review needs some words.");
	if (content.length < 20) throw new Error("Please write a little more — at least a couple of sentences.");
	if (!Number.isFinite(rating) || rating < 1 || rating > 5) throw new Error("Choose a rating from 1 to 5.");
	return {
		clientName,
		company,
		role,
		rating,
		content,
		project,
		website
	};
}).handler(submitReview_createServerFn_handler, async ({ data }) => {
	return {
		ok: true,
		status: "pending",
		receivedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
});
//#endregion
export { submitReview_createServerFn_handler };
