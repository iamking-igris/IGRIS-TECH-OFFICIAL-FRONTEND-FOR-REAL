import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-nhiT8qAJ.js
function trim(value) {
	return String(value ?? "").trim();
}
var submitProjectInquiry_createServerFn_handler = createServerRpc({
	id: "819475b6451f4b85af284b534ac8a87cdb90b98aa2e3f90d85a7bf5ed8d8af64",
	name: "submitProjectInquiry",
	filename: "src/lib/contact.ts"
}, (opts) => submitProjectInquiry.__executeServer(opts));
var submitProjectInquiry = createServerFn({ method: "POST" }).validator((raw) => {
	const name = trim(raw.name);
	const email = trim(raw.email);
	const type = trim(raw.type);
	const description = trim(raw.description);
	const company = trim(raw.company);
	const budget = trim(raw.budget);
	const timeline = trim(raw.timeline);
	const website = trim(raw.website);
	const contactMethod = trim(raw.contactMethod);
	if (!name) throw new Error("Name is required.");
	if (!email) throw new Error("Email is required.");
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Enter a valid email address.");
	if (!type) throw new Error("Project type is required.");
	if (!description) throw new Error("Project description is required.");
	if (website && !/^https?:\/\//i.test(website) && !website.includes(".")) throw new Error("Enter a valid website or leave it blank.");
	return {
		name,
		email,
		company,
		type,
		description,
		budget,
		timeline,
		website,
		contactMethod
	};
}).handler(submitProjectInquiry_createServerFn_handler, async ({ data }) => {
	return {
		ok: true,
		receivedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
});
//#endregion
export { submitProjectInquiry_createServerFn_handler };
