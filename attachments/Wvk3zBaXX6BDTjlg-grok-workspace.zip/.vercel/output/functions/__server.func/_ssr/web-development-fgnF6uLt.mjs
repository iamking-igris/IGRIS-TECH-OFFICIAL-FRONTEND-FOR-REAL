import { V as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as service } from "./router-bk_2vDcH.mjs";
import { t as ServicePage } from "./service-page-DBO2VnvV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/web-development-fgnF6uLt.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServicePage, { service });
//#endregion
export { SplitComponent as component };
