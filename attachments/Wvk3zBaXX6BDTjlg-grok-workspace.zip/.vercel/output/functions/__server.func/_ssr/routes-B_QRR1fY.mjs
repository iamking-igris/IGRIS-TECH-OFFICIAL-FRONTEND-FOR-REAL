import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, V as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Container, S as websiteJsonLd, b as organizationJsonLd, c as futureProductsNote, g as ButtonLink, l as featuredProjects, p as services, s as ecosystemProducts, w as cn } from "./router-bk_2vDcH.mjs";
import { t as JsonLd } from "./json-ld-IR7igJk0.mjs";
import { t as StatusChip } from "./status-chip-DCrX7XOg.mjs";
import { t as CtaBand } from "./cta-band-DznpNq9S.mjs";
import { n as Reveal, t as ProcessSection } from "./process-section-CSeq6EZm.mjs";
import { t as ProjectRow } from "./project-row-CaCPCXKt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B_QRR1fY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AboutSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-hairline bg-paper text-coal",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid gap-12 py-20 md:grid-cols-12 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "md:col-span-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-tech mb-4 !text-coal/50",
					children: "About / 06"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl font-semibold tracking-[-0.03em] text-coal md:text-5xl",
					children: "Built for the long term."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "md:col-span-7",
				delay: 80,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg leading-relaxed text-coal/80",
						children: "IGRIS Tech helps people and businesses turn ideas into digital products while building the experience and foundation needed to eventually create technology of its own."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-10 space-y-4 font-display text-2xl font-semibold tracking-[-0.03em] text-coal md:text-3xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Build for clients." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Learn from every project." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Create what comes next." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/about",
						className: "mt-10 inline-flex items-center gap-2 text-sm text-coal",
						children: ["About the company", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "btn-arrow",
							"aria-hidden": true,
							children: "→"
						})]
					})
				]
			})]
		})
	});
}
function SectionHeader({ kicker, title, description, invert = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("mb-12 grid gap-6 md:mb-16 md:grid-cols-12 md:items-end", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:col-span-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("label-tech mb-4", invert && "!text-coal/45"),
				children: kicker
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: cn("max-w-2xl font-display text-4xl font-semibold tracking-[-0.03em] md:text-5xl", invert ? "text-coal" : "text-ink"),
				children: title
			})]
		}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("max-w-sm text-sm leading-relaxed md:col-span-5 md:justify-self-end md:text-base", invert ? "text-coal/70" : "text-quiet"),
			children: description
		}) : null]
	});
}
function EcosystemSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-hairline",
		id: "ecosystem",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-20 md:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					kicker: "Ecosystem / 05",
					title: "The IGRIS ecosystem",
					description: "Client work is what we build for others. The ecosystem is what we build for ourselves. Connected — not the same catalogue."
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-10 md:grid-cols-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-hairline pt-6 md:col-span-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs tracking-widest text-faint",
								children: "PARENT"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 font-display text-2xl font-semibold tracking-[-0.03em]",
								children: "IGRIS Tech"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-quiet",
								children: "The company. Client work, and the public face of the products that follow."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 font-mono text-xs tracking-wider text-faint",
								children: "igristech.com"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "md:col-span-8",
						children: [ecosystemProducts.map((product, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							id: product.slug,
							className: "border-t border-hairline py-7 last:border-b",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-mono text-xs tracking-widest text-faint",
										children: [
											String(i + 1).padStart(2, "0"),
											" / ",
											product.category.toUpperCase()
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { children: product.status.toUpperCase() })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 font-display text-3xl font-semibold tracking-[-0.03em]",
									children: product.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-lg text-sm leading-relaxed text-quiet",
									children: product.description
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 font-mono text-xs tracking-wider text-faint",
									children: product.url ?? `${product.subdomain} — not live yet`
								})
							]
						}, product.slug)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-t border-hairline py-7 last:border-b",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs tracking-widest text-faint",
									children: "03 / FUTURE"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 font-display text-3xl font-semibold tracking-[-0.03em]",
									children: "Future products"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-lg text-sm leading-relaxed text-quiet",
									children: futureProductsNote
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/ecosystem",
					className: "mt-10 inline-flex items-center gap-2 text-sm text-ink",
					children: ["The ecosystem", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "btn-arrow",
						"aria-hidden": true,
						children: "→"
					})]
				})
			]
		})
	});
}
var SQRT3 = Math.sqrt(3);
var INK = {
	r: 243,
	g: 243,
	b: 240
};
function hexPixel(col, row, size) {
	return {
		x: size * SQRT3 * (col + .5 * (row & 1)),
		y: size * 1.5 * row
	};
}
function neighbors(col, row) {
	return row & 1 ? [
		[col + 1, row],
		[col - 1, row],
		[col, row - 1],
		[col + 1, row - 1],
		[col, row + 1],
		[col + 1, row + 1]
	] : [
		[col + 1, row],
		[col - 1, row],
		[col - 1, row - 1],
		[col, row - 1],
		[col - 1, row + 1],
		[col, row + 1]
	];
}
function hexRing(cx, cy, radius) {
	const pts = [];
	for (let i = 0; i < 6; i++) {
		const a = Math.PI / 180 * (60 * i - 30);
		pts.push({
			x: cx + Math.cos(a) * radius,
			y: cy + Math.sin(a) * radius
		});
	}
	return pts;
}
function strokeHex(ctx, pts, progress) {
	const p = Math.max(0, Math.min(1, progress));
	ctx.beginPath();
	ctx.moveTo(pts[0].x, pts[0].y);
	const edges = 6;
	const drawn = p * edges;
	for (let i = 1; i <= edges; i++) {
		const t = Math.max(0, Math.min(1, drawn - (i - 1)));
		if (t <= 0) break;
		const a = pts[i - 1];
		const b = pts[i % 6];
		ctx.lineTo(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
	}
	if (p >= 1) ctx.closePath();
	ctx.stroke();
}
function LivingGrid({ className }) {
	const wrapRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const wrap = wrapRef.current;
		const canvas = canvasRef.current;
		if (!wrap || !canvas) return;
		const ctx = canvas.getContext("2d", { alpha: true });
		if (!ctx) return;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const coarse = window.matchMedia("(pointer: coarse)").matches;
		let width = 0;
		let height = 0;
		let dpr = 1;
		let nodes = [];
		let edges = [];
		let markOuter = [];
		let markInner = [];
		let markMid = [];
		let raf = 0;
		let visible = true;
		let last = performance.now();
		const pointer = {
			x: 0,
			y: 0,
			active: false,
			tx: 0,
			ty: 0
		};
		let cx = 0;
		let cy = 0;
		let markR = 0;
		function rebuild() {
			const rect = wrap.getBoundingClientRect();
			width = Math.max(1, Math.floor(rect.width));
			height = Math.max(1, Math.floor(rect.height));
			dpr = Math.min(2, window.devicePixelRatio || 1);
			canvas.width = Math.floor(width * dpr);
			canvas.height = Math.floor(height * dpr);
			canvas.style.width = `${width}px`;
			canvas.style.height = `${height}px`;
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			const size = coarse ? Math.max(40, Math.min(52, width / 8)) : Math.max(28, Math.min(38, width / 14));
			const colCount = Math.ceil(width / (size * SQRT3)) + 2;
			const rowCount = Math.ceil(height / (size * 1.5)) + 2;
			const ox = (width - (colCount - 1) * size * SQRT3) / 2;
			const oy = (height - (rowCount - 1) * size * 1.5) / 2;
			const index = /* @__PURE__ */ new Map();
			nodes = [];
			for (let row = 0; row < rowCount; row++) for (let col = 0; col < colCount; col++) {
				const p = hexPixel(col, row, size);
				const x = p.x + ox;
				const y = p.y + oy;
				if (x < -size || y < -size || x > width + size || y > height + size) continue;
				index.set(`${col},${row}`, nodes.length);
				nodes.push({
					x,
					y,
					ox: x,
					oy: y,
					vx: 0,
					vy: 0,
					seed: (col * 13 + row * 7) * .37,
					col,
					row
				});
			}
			edges = [];
			const seen = /* @__PURE__ */ new Set();
			for (const n of nodes) for (const [nc, nr] of neighbors(n.col, n.row)) {
				const j = index.get(`${nc},${nr}`);
				if (j == null) continue;
				const i = index.get(`${n.col},${n.row}`);
				if (i == null) continue;
				const key = i < j ? `${i}-${j}` : `${j}-${i}`;
				if (seen.has(key)) continue;
				seen.add(key);
				const spine = (i + j) % 7 === 0;
				edges.push({
					a: i,
					b: j,
					spine
				});
			}
			cx = width * .52;
			cy = height * .5;
			markR = Math.min(width, height) * (coarse ? .28 : .24);
			markOuter = hexRing(cx, cy, markR);
			markMid = hexRing(cx, cy, markR * .72);
			markInner = hexRing(cx, cy, markR * .46);
		}
		function drawMark(progress, fillAlpha) {
			ctx.lineJoin = "miter";
			ctx.lineCap = "butt";
			ctx.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},${.55 * Math.min(1, progress)})`;
			ctx.lineWidth = 1.35;
			strokeHex(ctx, markOuter, progress);
			ctx.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},${.28 * Math.min(1, progress)})`;
			ctx.lineWidth = 1;
			strokeHex(ctx, markMid, progress - .12);
			ctx.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},${.7 * Math.min(1, progress - .2)})`;
			ctx.lineWidth = 1.2;
			strokeHex(ctx, markInner, progress - .22);
			if (progress > .55 && fillAlpha > 0) {
				ctx.save();
				ctx.globalAlpha = fillAlpha;
				ctx.beginPath();
				ctx.moveTo(markOuter[0].x, markOuter[0].y);
				for (let i = 1; i < 6; i++) ctx.lineTo(markOuter[i].x, markOuter[i].y);
				ctx.closePath();
				ctx.moveTo(markInner[0].x, markInner[0].y);
				for (let i = 5; i >= 0; i--) ctx.lineTo(markInner[i].x, markInner[i].y);
				ctx.closePath();
				ctx.fillStyle = `rgba(${INK.r},${INK.g},${INK.b},0.045)`;
				ctx.fill("evenodd");
				ctx.restore();
			}
			if (progress > .85) {
				ctx.fillStyle = `rgba(${INK.r},${INK.g},${INK.b},0.85)`;
				ctx.fillRect(cx - 2, cy - 2, 4, 4);
			}
		}
		function drawStatic() {
			ctx.clearRect(0, 0, width, height);
			ctx.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},0.09)`;
			ctx.lineWidth = 1;
			for (const e of edges) {
				if (!e.spine && (e.a + e.b) % 4 !== 0) continue;
				const a = nodes[e.a];
				const b = nodes[e.b];
				ctx.beginPath();
				ctx.moveTo(a.x, a.y);
				ctx.lineTo(b.x, b.y);
				ctx.stroke();
			}
			drawMark(1, 1);
			ctx.fillStyle = `rgba(${INK.r},${INK.g},${INK.b},0.35)`;
			for (const n of nodes) {
				if ((n.col + n.row) % 3 !== 0) continue;
				ctx.fillRect(n.x - 1, n.y - 1, 2, 2);
			}
		}
		function step(now) {
			const dt = Math.min(32, now - last);
			last = now;
			const t = now * .001;
			const assemble = Math.min(1, t / 2.4);
			pointer.x += (pointer.tx - pointer.x) * .16;
			pointer.y += (pointer.ty - pointer.y) * .16;
			const radius = coarse ? 0 : 140;
			const radius2 = radius * radius;
			for (const n of nodes) {
				const idleX = Math.sin(t * .22 + n.seed) * .4;
				const idleY = Math.cos(t * .18 + n.seed * 1.3) * .4;
				let tx = n.ox + idleX;
				let ty = n.oy + idleY;
				if (pointer.active && radius > 0) {
					const dx = n.ox - pointer.x;
					const dy = n.oy - pointer.y;
					const d2 = dx * dx + dy * dy;
					if (d2 < radius2 && d2 > .25) {
						const d = Math.sqrt(d2);
						const f = (1 - d / radius) ** 2;
						tx += dx / d * f * 14;
						ty += dy / d * f * 14;
					}
				}
				n.vx = (n.vx + (tx - n.x) * .1) * .8;
				n.vy = (n.vy + (ty - n.y) * .1) * .8;
				n.x += n.vx * (dt / 16.67);
				n.y += n.vy * (dt / 16.67);
			}
			ctx.clearRect(0, 0, width, height);
			ctx.lineJoin = "miter";
			ctx.lineCap = "butt";
			for (const e of edges) {
				const a = nodes[e.a];
				const b = nodes[e.b];
				const mx = (a.x + b.x) * .5;
				const my = (a.y + b.y) * .5;
				let prox = 0;
				if (pointer.active && radius > 0) {
					const d = Math.hypot(mx - pointer.x, my - pointer.y);
					prox = Math.max(0, 1 - d / radius);
				}
				const keep = e.spine || (e.a + e.b) % 4 === 0;
				if (!keep && prox < .14) continue;
				const alpha = keep ? .08 + prox * .34 : .03 + prox * .4;
				ctx.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},${alpha})`;
				ctx.lineWidth = e.spine ? 1.1 : 1;
				ctx.beginPath();
				ctx.moveTo(a.x, a.y);
				ctx.lineTo(b.x, b.y);
				ctx.stroke();
			}
			drawMark(assemble, .55 + .45 * Math.sin(t * .35));
			for (const n of nodes) {
				const life = .5 + .5 * Math.sin(t * .32 + n.seed);
				if (life < .18 && !pointer.active) continue;
				let prox = 0;
				if (pointer.active && radius > 0) {
					const d = Math.hypot(n.x - pointer.x, n.y - pointer.y);
					prox = Math.max(0, 1 - d / radius);
				}
				const s = .9 + prox * 1.6 + life * .4;
				const alpha = .16 + life * .22 + prox * .5;
				ctx.fillStyle = `rgba(${INK.r},${INK.g},${INK.b},${alpha})`;
				ctx.fillRect(n.x - s, n.y - s, s * 2, s * 2);
			}
			if (pointer.active && !coarse) {
				ctx.strokeStyle = `rgba(${INK.r},${INK.g},${INK.b},0.45)`;
				ctx.lineWidth = 1;
				ctx.beginPath();
				ctx.moveTo(pointer.x - 7, pointer.y);
				ctx.lineTo(pointer.x + 7, pointer.y);
				ctx.moveTo(pointer.x, pointer.y - 7);
				ctx.lineTo(pointer.x, pointer.y + 7);
				ctx.stroke();
			}
		}
		function loop(now) {
			if (!visible) return;
			if (reduced) {
				drawStatic();
				return;
			}
			step(now);
			raf = requestAnimationFrame(loop);
		}
		function onPointer(e) {
			if (coarse) return;
			const rect = canvas.getBoundingClientRect();
			pointer.tx = e.clientX - rect.left;
			pointer.ty = e.clientY - rect.top;
			pointer.active = true;
		}
		function onLeave() {
			pointer.active = false;
		}
		rebuild();
		if (reduced) drawStatic();
		else raf = requestAnimationFrame(loop);
		const ro = new ResizeObserver(() => {
			rebuild();
			if (reduced) drawStatic();
		});
		ro.observe(wrap);
		const io = new IntersectionObserver(([entry]) => {
			visible = Boolean(entry?.isIntersecting);
			if (visible && !reduced) {
				last = performance.now();
				cancelAnimationFrame(raf);
				raf = requestAnimationFrame(loop);
			} else cancelAnimationFrame(raf);
		});
		io.observe(wrap);
		canvas.addEventListener("pointermove", onPointer, { passive: true });
		canvas.addEventListener("pointerdown", onPointer, { passive: true });
		canvas.addEventListener("pointerleave", onLeave);
		canvas.addEventListener("pointercancel", onLeave);
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
			io.disconnect();
			canvas.removeEventListener("pointermove", onPointer);
			canvas.removeEventListener("pointerdown", onPointer);
			canvas.removeEventListener("pointerleave", onLeave);
			canvas.removeEventListener("pointercancel", onLeave);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className: cn("relative h-full w-full", className),
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "relative block h-full w-full touch-none"
		})
	});
}
function HomeHero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden border-b border-hairline",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 hex-grid opacity-40 md:opacity-20" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto grid max-w-[1440px] items-end gap-10 px-5 pb-16 pt-24 sm:px-8 md:min-h-[100dvh] md:grid-cols-12 md:items-center md:gap-8 md:pb-20 md:pt-28 lg:px-12 xl:px-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-6 lg:col-span-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech hero-rise mb-7",
						children: "IGRIS / 00"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "hero-rise font-display text-[clamp(2.6rem,8vw,6.8rem)] font-semibold leading-[0.92] tracking-[-0.045em] text-ink",
						style: { animationDelay: "80ms" },
						children: [
							"We build",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"what’s next."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hero-rise mt-7 max-w-md text-base leading-relaxed text-quiet md:mt-8 md:text-lg",
						style: { animationDelay: "160ms" },
						children: "IGRIS Tech builds digital products, websites, software, and intelligent solutions for individuals, brands, and businesses."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-rise mt-9 flex flex-wrap items-center gap-3 md:mt-10 md:gap-4",
						style: { animationDelay: "240ms" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
							to: "/contact",
							variant: "primary",
							children: "Start a Project"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
							to: "/work",
							variant: "ghost",
							children: "Explore Our Work"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-[220px] sm:h-[280px] md:col-span-6 md:h-[min(68vh,620px)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LivingGrid, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pointer-events-none absolute bottom-2 right-0 font-mono text-[10px] tracking-[0.18em] text-faint",
					children: "SYSTEM / GRID"
				})]
			})]
		})]
	});
}
function WorkSection() {
	const items = featuredProjects();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-hairline",
		id: "work",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-20 md:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					kicker: "Work / 02",
					title: "Selected work",
					description: "Real client work will be published here. The structure is ready — the case studies are not invented."
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: items.map((project, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectRow, {
						project,
						index: i,
						reverse: i % 2 === 1
					}, project.slug))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/work",
						className: "inline-flex items-center gap-2 text-sm text-ink",
						children: ["All work", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "btn-arrow",
							"aria-hidden": true,
							children: "→"
						})]
					})
				})
			]
		})
	});
}
function ServicesSection() {
	const [active, setActive] = (0, import_react.useState)(0);
	const current = services[active] ?? services[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-hairline",
		id: "services",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-20 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				kicker: "Services / 01",
				title: "What we build",
				description: "Four capabilities. One company you can hire to take an idea into a working product."
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 md:grid-cols-12 md:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "md:col-span-7",
					children: services.map((service, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-t border-hairline last:border-b",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: service.href,
							onMouseEnter: () => setActive(i),
							onFocus: () => setActive(i),
							className: cn("group flex items-baseline justify-between gap-6 py-6 transition-colors duration-150 md:py-7", i === active ? "text-ink" : "text-quiet hover:text-ink"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex min-w-0 items-baseline gap-5 md:gap-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs tracking-widest text-faint",
									children: service.index
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-2xl font-semibold tracking-[-0.03em] md:text-4xl",
									children: service.name
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("hidden shrink-0 text-sm transition-opacity duration-150 md:inline", i === active ? "opacity-100" : "opacity-0 group-hover:opacity-100"),
								children: "View →"
							})]
						})
					}, service.slug))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "md:col-span-5 md:border-l md:border-hairline md:pl-10 md:pt-6",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs tracking-widest text-faint",
							children: [
								current.index,
								" / ",
								current.name.toUpperCase()
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-lg leading-relaxed text-ink",
							children: current.short
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-quiet",
							children: current.problem
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-sm leading-relaxed text-quiet",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-ink",
								children: "For. "
							}), current.forWhom]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: current.href,
							className: "mt-8 inline-flex items-center gap-2 text-sm text-ink",
							children: [
								"Explore ",
								current.name,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "btn-arrow",
									"aria-hidden": true,
									children: "→"
								})
							]
						})
					]
				})]
			})]
		})
	});
}
/**
* Genuine testimonials only.
* Public UI renders reviews with status === "approved".
* Submissions enter as pending and stay off the public page until an admin approves them.
* This array is the local/mock source — swap for an API later without changing the UI.
*/
var reviews = [];
function publishedReviews() {
	return reviews.filter((r) => r.status === "approved");
}
function ReviewsSection() {
	const items = publishedReviews();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-hairline bg-paper text-coal",
		id: "reviews",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-20 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				invert: true,
				kicker: "Notes / 03",
				title: "What clients say — when they choose to.",
				description: "Reviews appear here once they have been approved. We do not publish invented testimonials, ratings, or client counts."
			}) }), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 md:grid-cols-12 md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl text-base leading-relaxed text-coal/70 md:col-span-7",
					children: "Nothing here yet. When a client is willing to put their name on a note about the work, it will live on this page — attributed, and unedited for theatre."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-5 md:justify-self-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
						to: "/review",
						variant: "inverse",
						arrow: true,
						children: "Leave a Review"
					})
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-8 md:grid-cols-2",
				children: items.map((review) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-t border-coal/15 pt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-[10px] tracking-widest text-coal/45",
							children: [Array.from({ length: review.rating }, () => "●").join(" "), Array.from({ length: 5 - review.rating }, () => "○").join(" ")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
							className: "mt-4 text-lg leading-relaxed text-coal",
							children: review.content
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-sm text-coal/70",
							children: [
								review.clientName,
								review.role ? `, ${review.role}` : "",
								review.company ? ` — ${review.company}` : ""
							]
						})
					]
				}, review.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-12 text-sm text-coal/70",
				children: [
					"Worked with IGRIS?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/review",
						className: "text-coal underline-offset-4 hover:underline",
						children: "Leave a review"
					}),
					". Notes are published after we read them."
				]
			})] })]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: organizationJsonLd() }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: websiteJsonLd() }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeHero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServicesSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewsSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProcessSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EcosystemSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, { kicker: "Contact / 07" })
		]
	});
}
//#endregion
export { Home as component };
