import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, V as require_jsx_runtime, _ as createRootRoute, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter, z as notFound } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/container-D9BiIV4U.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Container({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mx-auto w-full max-w-[1440px] px-5 sm:px-8 lg:px-12 xl:px-16", className),
		children
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/seo-ZHFQQ1Uy.js
var variants = {
	primary: "bg-ink text-canvas border border-ink hover:bg-paper hover:text-coal",
	inverse: "bg-canvas text-ink border border-canvas hover:bg-raised",
	ghost: "bg-transparent text-ink border border-hairline hover:border-quiet hover:bg-raised/40",
	text: "bg-transparent text-ink hover:text-paper px-0 h-auto min-h-0 border-0"
};
var base = "inline-flex items-center justify-center gap-2.5 h-12 min-h-12 px-6 text-sm font-medium tracking-wide transition-[color,background-color,border-color,transform] duration-150 ease-out active:scale-[0.96] disabled:opacity-50 disabled:pointer-events-none";
function withArrow(children, arrow) {
	if (!arrow) return children;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "btn-arrow",
		"aria-hidden": true,
		children: "→"
	})] });
}
function ButtonLink({ to, href, variant = "primary", className, children, external, arrow = true }) {
	const classes = cn(base, variants[variant], className);
	const content = withArrow(children, arrow && variant !== "text");
	if (href) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		className: classes,
		...external ? {
			target: "_blank",
			rel: "noreferrer"
		} : {},
		children: content
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: to ?? "/",
		className: classes,
		children: content
	});
}
function Button({ variant = "primary", className, type = "button", arrow = false, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(base, variants[variant], className),
		...props,
		children: withArrow(children, arrow && variant !== "text")
	});
}
var SITE = {
	name: "IGRIS Tech",
	legalName: "IGRIS Tech",
	domain: "https://igristech.com",
	tagline: "We build what's next.",
	description: "IGRIS Tech builds digital products, software, websites, and intelligent solutions for individuals, brands, and businesses.",
	email: null,
	social: []
};
var NAV = [
	{
		label: "Services",
		to: "/services"
	},
	{
		label: "Work",
		to: "/work"
	},
	{
		label: "Ecosystem",
		to: "/ecosystem"
	},
	{
		label: "About",
		to: "/about"
	}
];
function absoluteUrl(path = "/") {
	if (path.startsWith("http")) return path;
	const normalized = path.startsWith("/") ? path : `/${path}`;
	return `${SITE.domain}${normalized}`;
}
function pageHead({ title, description, path = "/", noIndex }) {
	const url = absoluteUrl(path);
	return {
		meta: [
			{ title },
			{
				name: "description",
				content: description
			},
			{
				name: "theme-color",
				content: "#070708"
			},
			{
				name: "application-name",
				content: SITE.name
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: description
			},
			{
				property: "og:url",
				content: url
			},
			{
				property: "og:site_name",
				content: SITE.name
			},
			{
				name: "twitter:title",
				content: title
			},
			{
				name: "twitter:description",
				content: description
			},
			...noIndex ? [{
				name: "robots",
				content: "noindex, nofollow"
			}] : []
		],
		links: [{
			rel: "canonical",
			href: url
		}]
	};
}
function organizationJsonLd() {
	return {
		"@context": "https://schema.org",
		"@type": "Organization",
		name: SITE.name,
		url: SITE.domain,
		description: SITE.description,
		logo: `${SITE.domain}/brand/igris-mark.png`
	};
}
function websiteJsonLd() {
	return {
		"@context": "https://schema.org",
		"@type": "WebSite",
		name: SITE.name,
		url: SITE.domain,
		description: SITE.description
	};
}
function serviceJsonLd(name, description, url) {
	return {
		"@context": "https://schema.org",
		"@type": "Service",
		name,
		description,
		url,
		provider: {
			"@type": "Organization",
			name: SITE.name,
			url: SITE.domain
		}
	};
}
function breadcrumbJsonLd(items) {
	return {
		"@context": "https://schema.org",
		"@type": "BreadcrumbList",
		itemListElement: items.map((item, i) => ({
			"@type": "ListItem",
			position: i + 1,
			name: item.name,
			item: absoluteUrl(item.path)
		}))
	};
}
function creativeWorkJsonLd(input) {
	return {
		"@context": "https://schema.org",
		"@type": "CreativeWork",
		name: input.name,
		description: input.description,
		url: input.url,
		creator: {
			"@type": "Organization",
			name: SITE.name,
			url: SITE.domain
		},
		...input.dateCreated ? { dateCreated: input.dateCreated } : {}
	};
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/services-CsiE3ino.js
var services = [
	{
		index: "01",
		name: "Web Development",
		slug: "web-development",
		href: "/services/web-development",
		short: "Websites and web applications designed around a real job to do.",
		description: "We design and build websites and web applications that are fast, clear, and built to last — from a company’s public face to the product people actually use.",
		forWhom: "Founders, brands, and operators who need a site or web product that holds up in production — not a template with a new coat of paint.",
		problem: "Most websites are assembled. They look finished and fail at the work: unclear, slow, hard to change, and disconnected from the business.",
		points: [
			"Marketing and product websites",
			"Web applications and dashboards",
			"Performance, accessibility, and SEO foundations",
			"Design systems that can grow with the product"
		],
		seoTitle: "Web Development Services — IGRIS Tech",
		seoDescription: "IGRIS Tech builds modern websites and web applications around real business goals — fast, accessible, and ready to grow."
	},
	{
		index: "02",
		name: "Software Development",
		slug: "software-development",
		href: "/services/software-development",
		short: "Custom software when off-the-shelf tools are not enough.",
		description: "We build custom software — internal systems, digital products, and the infrastructure around them — when the work does not fit a generic tool.",
		forWhom: "Teams whose operations, product, or customers have outgrown spreadsheets, plugins, and disconnected apps.",
		problem: "Generic software forces the business to bend. Custom software is expensive when it is built without a clear product and technical direction.",
		points: [
			"Custom product development",
			"Internal tools and operational systems",
			"APIs and platform architecture",
			"Codebases meant to be maintained, not replaced"
		],
		seoTitle: "Software Development — IGRIS Tech",
		seoDescription: "Custom software and digital products from IGRIS Tech — systems designed around how your business actually works."
	},
	{
		index: "03",
		name: "AI Solutions",
		slug: "ai-solutions",
		href: "/services/ai-solutions",
		short: "AI features and tools that are useful in production.",
		description: "We integrate AI where it creates real leverage — assistants, workflows, and product features that have to work on ordinary days, not just in a demo.",
		forWhom: "Product and operations teams who have a specific job for AI, not a mandate to “add AI” somewhere.",
		problem: "Most AI work stops at a prototype. The hard part is making it reliable, scoped, and worth the complexity it adds.",
		points: [
			"AI features inside existing products",
			"Intelligent internal tools",
			"Workflow and document intelligence",
			"Practical, production-minded implementation"
		],
		seoTitle: "AI Solutions — IGRIS Tech",
		seoDescription: "IGRIS Tech builds AI-powered experiences and intelligent tools that work in real products, not just prototypes."
	},
	{
		index: "04",
		name: "Automation",
		slug: "automation",
		href: "/services/automation",
		short: "Systems that remove repetitive work and make operations reliable.",
		description: "We design automation that takes friction out of operations — connecting tools, reducing manual work, and making processes something you can trust.",
		forWhom: "Operators and founders spending too much time moving information between tools, people, and spreadsheets.",
		problem: "Manual processes do not scale, and automation without process design just moves the mess into software.",
		points: [
			"Workflow automation",
			"Integrations between existing tools",
			"Operational systems and reporting",
			"Process design before implementation"
		],
		seoTitle: "Automation Services — IGRIS Tech",
		seoDescription: "IGRIS Tech designs automation systems that reduce repetitive work and make operations more reliable."
	}
];
var supportingCapabilities = [
	{
		name: "Digital Products",
		text: "From first version to a product people return to — structure, interface, and the software underneath."
	},
	{
		name: "Custom Systems",
		text: "Software shaped around how the work actually happens, not around a vendor’s idea of a workflow."
	},
	{
		name: "Integrations",
		text: "Connecting the tools you already use so information does not have to be copied by hand."
	}
];
function getService(slug) {
	return services.find((s) => s.slug === slug);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/projects-DR5Pp2FS.js
/**
* Structured slots for case studies.
* These are not invented clients, results, or logos.
* Replace fields when real work is ready to publish.
*/
var projects = [
	{
		id: "proj_web_platform",
		slug: "web-platform",
		title: "Web platform",
		client: "To be announced",
		category: "Web Development",
		year: null,
		description: "A web platform case study will be published here when the work is ready to share.",
		overview: "This entry is a structured placeholder. The case study format is in place so real work can be published without rebuilding the site.",
		challenge: "",
		objectives: [],
		approach: "",
		design: "",
		development: "",
		keyDecisions: [],
		results: null,
		services: ["web-development"],
		technologies: [],
		gallery: [],
		testimonial: null,
		featuredImage: null,
		url: null,
		featured: true,
		published: true,
		placeholder: true,
		status: "in-preparation",
		visual: "alpha",
		publishedAt: null,
		seoTitle: "Web platform — IGRIS Tech",
		seoDescription: "A web development case study from IGRIS Tech. Published when the work is ready to share."
	},
	{
		id: "proj_custom_system",
		slug: "custom-system",
		title: "Custom system",
		client: "To be announced",
		category: "Software Development",
		year: null,
		description: "A custom software case study will be published here when the work is ready to share.",
		overview: "This entry is a structured placeholder. Challenge, approach, design, and development will be written from the actual project — not invented.",
		challenge: "",
		objectives: [],
		approach: "",
		design: "",
		development: "",
		keyDecisions: [],
		results: null,
		services: ["software-development"],
		technologies: [],
		gallery: [],
		testimonial: null,
		featuredImage: null,
		url: null,
		featured: true,
		published: true,
		placeholder: true,
		status: "in-preparation",
		visual: "beta",
		publishedAt: null,
		seoTitle: "Custom system — IGRIS Tech",
		seoDescription: "A software development case study from IGRIS Tech. Published when the work is ready to share."
	},
	{
		id: "proj_intelligent_product",
		slug: "intelligent-product",
		title: "Intelligent product",
		client: "To be announced",
		category: "AI Solutions",
		year: null,
		description: "An intelligent product case study will be published here when the work is ready to share.",
		overview: "This entry is a structured placeholder. No metrics, quotes, or client names are fabricated to fill the page.",
		challenge: "",
		objectives: [],
		approach: "",
		design: "",
		development: "",
		keyDecisions: [],
		results: null,
		services: ["ai-solutions", "automation"],
		technologies: [],
		gallery: [],
		testimonial: null,
		featuredImage: null,
		url: null,
		featured: true,
		published: true,
		placeholder: true,
		status: "in-preparation",
		visual: "gamma",
		publishedAt: null,
		seoTitle: "Intelligent product — IGRIS Tech",
		seoDescription: "An AI and automation case study from IGRIS Tech. Published when the work is ready to share."
	}
];
function getProject(slug) {
	return projects.find((p) => p.slug === slug && p.published);
}
function featuredProjects() {
	return projects.filter((p) => p.published && p.featured);
}
function relatedProjects(slug) {
	return projects.filter((p) => p.published && p.slug !== slug);
}
function publishedProjects() {
	return projects.filter((p) => p.published);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-bk_2vDcH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "flex min-h-dvh flex-col items-center justify-center gap-4 bg-canvas px-6 text-center text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "label-tech",
				children: "Error"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold tracking-[-0.03em]",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-quiet",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
				to: "/",
				variant: "ghost",
				children: "Return Home"
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function LogoMark({ className, alt = "", onDark = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: onDark ? "/brand/igris-mark-on-dark.png" : "/brand/igris-mark.png",
		alt,
		width: 707,
		height: 755,
		className: cn("h-8 w-auto", className),
		decoding: "async"
	});
}
function BrandLockup({ className, onDark = true, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("flex items-center gap-2.5 md:gap-3", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, {
			onDark,
			className: cn("h-[1.7rem] w-auto translate-y-px md:h-8", compact && "h-7"),
			alt: ""
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("wordmark translate-y-px text-[0.62rem] text-current md:text-[0.72rem]", onDark ? "text-ink" : "text-coal"),
			children: "IGRIS TECH"
		})]
	});
}
/**
* Future public homes:
* igristech.com
* hosting.igristech.com
* studio.igristech.com
*
* URLs are only set when a product is actually live.
* Links are data-driven — do not hardcode live product URLs in copy.
*/
var ecosystemProducts = [{
	id: "eco_hosting",
	name: "IGRIS Hosting",
	slug: "hosting",
	description: "Infrastructure for the modern web. Product details will be published as the work lands.",
	status: "In development",
	category: "Infrastructure",
	logo: null,
	image: null,
	url: null,
	subdomain: "hosting.igristech.com",
	featured: true,
	launchDate: null
}, {
	id: "eco_studio",
	name: "IGRIS Studio",
	slug: "studio",
	description: "A product in the IGRIS ecosystem. Scope and features will be published when they are real.",
	status: "In development",
	category: "Platform",
	logo: null,
	image: null,
	url: null,
	subdomain: "studio.igristech.com",
	featured: true,
	launchDate: null
}];
var futureProductsNote = "Further products will sit on their own subdomains under igristech.com when they are ready.";
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-hairline bg-canvas",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid gap-16 py-16 md:grid-cols-12 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xs text-sm leading-relaxed text-quiet",
						children: "Building digital products for clients. Building an ecosystem of our own. The two are connected — they are not the same thing."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/contact",
						className: "mt-8 inline-flex items-center gap-2 text-sm text-ink",
						children: ["Start a Project", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "btn-arrow",
							"aria-hidden": true,
							children: "→"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-10 sm:grid-cols-3 md:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech mb-4",
						children: "Company"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/work",
								className: "text-ink/90 hover:text-ink",
								children: "Work"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/ecosystem",
								className: "text-ink/90 hover:text-ink",
								children: "Ecosystem"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/about",
								className: "text-ink/90 hover:text-ink",
								children: "About"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/contact",
								className: "text-ink/90 hover:text-ink",
								children: "Contact"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/review",
								className: "text-ink/90 hover:text-ink",
								children: "Leave a Review"
							}) })
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech mb-4",
						children: "Services"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3 text-sm",
						children: services.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: s.href,
							className: "text-ink/90 hover:text-ink",
							children: s.name
						}) }, s.slug))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label-tech mb-4",
						children: "Ecosystem"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3 text-sm",
						children: ecosystemProducts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/ecosystem",
							hash: p.slug,
							className: "text-ink/90 hover:text-ink",
							children: p.name
						}) }, p.slug))
					})] })
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-hairline",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "flex flex-col gap-3 py-6 text-xs text-faint md:flex-row md:items-center md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" IGRIS Tech. All rights reserved."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-x-5 gap-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privacy",
							className: "hover:text-quiet",
							children: "Privacy Policy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/terms",
							className: "hover:text-quiet",
							children: "Terms"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono tracking-wider",
							children: "BUILDING · AUTOMATING"
						})
					]
				})]
			})
		})]
	});
}
function SiteNav() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [hidden, setHidden] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const lastY = (0, import_react.useRef)(0);
	const ticking = (0, import_react.useRef)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		lastY.current = window.scrollY;
		const update = () => {
			const y = window.scrollY;
			const max = document.documentElement.scrollHeight - window.innerHeight;
			setProgress(max > 0 ? Math.min(1, y / max) : 0);
			setScrolled(y > 8);
			const delta = y - lastY.current;
			if (open || y < 56) setHidden(false);
			else if (delta > 12 && y > 96) setHidden(true);
			else if (delta < -10) setHidden(false);
			lastY.current = y;
			ticking.current = false;
		};
		const onScroll = () => {
			if (ticking.current) return;
			ticking.current = true;
			requestAnimationFrame(update);
		};
		update();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, [open]);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("fixed inset-x-0 top-0 z-50 transition-[transform,background-color,border-color,backdrop-filter] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]", hidden && !open ? "-translate-y-full" : "translate-y-0", scrolled || open ? "border-b border-hairline bg-canvas/92 backdrop-blur-md" : "border-b border-transparent bg-transparent"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scroll-progress pointer-events-none absolute inset-x-0 bottom-0 h-px bg-ink/70",
				style: { ["--progress"]: progress },
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-16 max-w-[1440px] items-center justify-between gap-6 px-5 sm:px-8 md:h-[4.5rem] lg:px-12 xl:px-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "min-w-0 shrink text-ink",
						"aria-label": "IGRIS Tech home",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "hidden items-center gap-9 lg:flex",
						"aria-label": "Primary",
						children: [NAV.map((item) => {
							const active = pathname === item.to || pathname.startsWith(`${item.to}/`);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("relative text-[0.8125rem] tracking-wide transition-colors duration-150 hover:text-ink", active ? "text-ink" : "text-quiet"),
								children: [item.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("absolute -bottom-1 left-0 h-px w-full origin-left bg-ink transition-transform duration-200", active ? "scale-x-100" : "scale-x-0"),
									"aria-hidden": true
								})]
							}, item.to);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/contact",
							className: "inline-flex h-10 items-center gap-2 border border-ink bg-ink px-4 text-[0.8125rem] font-medium text-canvas transition-[background-color,color] duration-150 hover:bg-paper hover:text-coal",
							children: ["Start a Project", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "btn-arrow",
								"aria-hidden": true,
								children: "→"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "relative flex h-11 w-11 shrink-0 items-center justify-center lg:hidden",
						"aria-expanded": open,
						"aria-controls": "mobile-nav",
						"aria-label": open ? "Close menu" : "Open menu",
						onClick: () => setOpen((v) => !v),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute h-px w-5 bg-ink transition-transform duration-200", open ? "translate-y-0 rotate-45" : "-translate-y-1.5") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute h-px w-5 bg-ink transition-opacity duration-150", open ? "opacity-0" : "opacity-100") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute h-px w-5 bg-ink transition-transform duration-200", open ? "translate-y-0 -rotate-45" : "translate-y-1.5") })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "mobile-nav",
				hidden: !open,
				className: "border-t border-hairline bg-canvas lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex max-h-[calc(100dvh-4rem)] flex-col overflow-y-auto px-5 py-8 sm:px-8",
					"aria-label": "Mobile",
					children: [NAV.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: "flex items-baseline justify-between border-b border-hairline py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-2xl font-semibold tracking-[-0.03em] text-ink",
							children: item.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[10px] tracking-widest text-faint",
							children: String(i + 1).padStart(2, "0")
						})]
					}, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/contact",
						className: "mt-8 inline-flex h-12 items-center justify-center gap-2 bg-ink text-sm font-medium text-canvas",
						children: ["Start a Project", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							children: "→"
						})]
					})]
				})
			})
		]
	});
}
function SiteGrid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "site-frame",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "site-frame-inner relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-0 left-1/3 site-frame-col" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-0 left-2/3 site-frame-col" })]
		})
	});
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh bg-canvas text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[60] focus:bg-ink focus:px-4 focus:py-2 focus:text-canvas",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteGrid, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function NotFoundPage() {
	(0, import_react.useEffect)(() => {
		document.title = "Page not found — IGRIS Tech";
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		className: "relative overflow-hidden border-b border-hairline",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 hex-grid opacity-50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "relative py-32 md:py-40",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-tech mb-6",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-10 h-24 w-24",
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 100 100",
						className: "h-full w-full",
						fill: "none",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								points: "50,6 93,31 93,69 50,94 7,69 7,31",
								stroke: "rgba(243,243,240,0.35)",
								strokeWidth: "1.4"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								points: "50,24 76,39 76,61 50,76 24,61 24,39",
								stroke: "rgba(243,243,240,0.55)",
								strokeWidth: "1.4"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: "47",
								y: "47",
								width: "6",
								height: "6",
								fill: "rgba(243,243,240,0.8)"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "max-w-2xl font-display text-4xl font-semibold tracking-[-0.03em] md:text-6xl",
					children: "Looks like this route doesn’t exist."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-md text-base leading-relaxed text-quiet",
					children: "The path you asked for isn’t part of the IGRIS system. Head home, or start a project."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-wrap gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
						to: "/",
						variant: "primary",
						children: "Return Home"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
						to: "/contact",
						variant: "ghost",
						children: "Start a Project"
					})]
				})
			]
		})]
	});
}
var styles_default = "/assets/styles-BQVF92dV.css";
var Route$14 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: SITE.name },
			{
				name: "theme-color",
				content: "#070708"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/png",
				href: "/brand/igris-mark-on-dark.png"
			},
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Outfit:wght@300;400;500;600;700&family=Syne:wght@500;600;700;800&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootComponent,
	notFoundComponent: NotFoundPage
});
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-canvas text-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$13 = () => import("./routes-B_QRR1fY.mjs");
var Route$13 = createFileRoute("/")({
	head: () => pageHead({
		title: "IGRIS Tech — Digital Products, Web Development & Software",
		description: "IGRIS Tech builds websites, software, AI solutions, and automation for individuals, brands, and businesses.",
		path: "/"
	}),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./about-BKn75TOC.mjs");
var Route$12 = createFileRoute("/about")({
	head: () => pageHead({
		title: "About IGRIS Tech",
		description: "IGRIS Tech helps people and businesses turn ideas into digital products while building technology of its own.",
		path: "/about"
	}),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./contact-KvjYAIp4.mjs");
var Route$11 = createFileRoute("/contact")({
	head: () => pageHead({
		title: "Start a Project — IGRIS Tech",
		description: "Tell IGRIS Tech what you want to build. We’ll review your project and get back to you.",
		path: "/contact"
	}),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./ecosystem-Bsvh9C6c.mjs");
var Route$10 = createFileRoute("/ecosystem")({
	head: () => pageHead({
		title: "The IGRIS Ecosystem — IGRIS Tech",
		description: "Products built by IGRIS Tech, including IGRIS Hosting and IGRIS Studio. IGRIS Tech is the parent technology brand.",
		path: "/ecosystem"
	}),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./privacy-C_PHdQtg.mjs");
var Route$9 = createFileRoute("/privacy")({
	head: () => pageHead({
		title: "Privacy Policy — IGRIS Tech",
		description: "How IGRIS Tech handles information submitted through this website.",
		path: "/privacy"
	}),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./review-BloAFVJO.mjs");
var Route$8 = createFileRoute("/review")({
	head: () => pageHead({
		title: "Leave a Review — IGRIS Tech",
		description: "Share a note about working with IGRIS Tech. Reviews are published only after they have been read and approved.",
		path: "/review"
	}),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./terms-BFXkjk-n.mjs");
var Route$7 = createFileRoute("/terms")({
	head: () => pageHead({
		title: "Terms — IGRIS Tech",
		description: "Terms of use for the IGRIS Tech public website.",
		path: "/terms"
	}),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./services-DHTj0G2k.mjs");
var Route$6 = createFileRoute("/services/")({
	head: () => pageHead({
		title: "Services — Web Development, Software, AI & Automation | IGRIS Tech",
		description: "Web development, software development, AI solutions, and automation from IGRIS Tech. Hire a team to design, build, and launch digital products.",
		path: "/services"
	}),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var service$3 = getService("ai-solutions");
var $$splitComponentImporter$5 = () => import("./ai-solutions-CnRoqlh7.mjs");
var Route$5 = createFileRoute("/services/ai-solutions")({
	head: () => pageHead({
		title: service$3.seoTitle,
		description: service$3.seoDescription,
		path: service$3.href
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var service$2 = getService("automation");
var $$splitComponentImporter$4 = () => import("./automation-DylNKeuq.mjs");
var Route$4 = createFileRoute("/services/automation")({
	head: () => pageHead({
		title: service$2.seoTitle,
		description: service$2.seoDescription,
		path: service$2.href
	}),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var service$1 = getService("software-development");
var $$splitComponentImporter$3 = () => import("./software-development-CLgFYDxN.mjs");
var Route$3 = createFileRoute("/services/software-development")({
	head: () => pageHead({
		title: service$1.seoTitle,
		description: service$1.seoDescription,
		path: service$1.href
	}),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var service = getService("web-development");
var $$splitComponentImporter$2 = () => import("./web-development-fgnF6uLt.mjs");
var Route$2 = createFileRoute("/services/web-development")({
	head: () => pageHead({
		title: service.seoTitle,
		description: service.seoDescription,
		path: service.href
	}),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./work-CDXHSOG1.mjs");
var Route$1 = createFileRoute("/work/")({
	head: () => pageHead({
		title: "Selected Work — IGRIS Tech",
		description: "Selected client work from IGRIS Tech. Case studies are published as they are ready to share.",
		path: "/work"
	}),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("../_slug-UO7h_Xxa.mjs");
var Route = createFileRoute("/work/$slug")({
	loader: ({ params }) => {
		const project = getProject(params.slug);
		if (!project) throw notFound();
		return { project };
	},
	head: ({ loaderData }) => pageHead({
		title: loaderData?.project.seoTitle ?? `${loaderData?.project.title} — IGRIS Tech`,
		description: loaderData?.project.seoDescription ?? loaderData?.project.description ?? "IGRIS Tech case study.",
		path: `/work/${loaderData?.project.slug ?? ""}`
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$14
});
var AboutRoute = Route$12.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$14
});
var ContactRoute = Route$11.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$14
});
var EcosystemRoute = Route$10.update({
	id: "/ecosystem",
	path: "/ecosystem",
	getParentRoute: () => Route$14
});
var PrivacyRoute = Route$9.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$14
});
var ReviewRoute = Route$8.update({
	id: "/review",
	path: "/review",
	getParentRoute: () => Route$14
});
var TermsRoute = Route$7.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$14
});
var ServicesIndexRoute = Route$6.update({
	id: "/services/",
	path: "/services/",
	getParentRoute: () => Route$14
});
var ServicesAiSolutionsRoute = Route$5.update({
	id: "/services/ai-solutions",
	path: "/services/ai-solutions",
	getParentRoute: () => Route$14
});
var ServicesAutomationRoute = Route$4.update({
	id: "/services/automation",
	path: "/services/automation",
	getParentRoute: () => Route$14
});
var ServicesSoftwareDevelopmentRoute = Route$3.update({
	id: "/services/software-development",
	path: "/services/software-development",
	getParentRoute: () => Route$14
});
var ServicesWebDevelopmentRoute = Route$2.update({
	id: "/services/web-development",
	path: "/services/web-development",
	getParentRoute: () => Route$14
});
var WorkIndexRoute = Route$1.update({
	id: "/work/",
	path: "/work/",
	getParentRoute: () => Route$14
});
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	ContactRoute,
	EcosystemRoute,
	PrivacyRoute,
	ReviewRoute,
	TermsRoute,
	ServicesAiSolutionsRoute,
	ServicesAutomationRoute,
	ServicesSoftwareDevelopmentRoute,
	ServicesWebDevelopmentRoute,
	WorkSlugRoute: Route.update({
		id: "/work/$slug",
		path: "/work/$slug",
		getParentRoute: () => Route$14
	}),
	ServicesIndexRoute,
	WorkIndexRoute
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { Container as C, websiteJsonLd as S, absoluteUrl as _, service$2 as a, organizationJsonLd as b, futureProductsNote as c, relatedProjects as d, getService as f, ButtonLink as g, Button as h, service$1 as i, featuredProjects as l, supportingCapabilities as m, Route as n, service$3 as o, services as p, service as r, ecosystemProducts as s, router_exports as t, publishedProjects as u, breadcrumbJsonLd as v, cn as w, serviceJsonLd as x, creativeWorkJsonLd as y };
