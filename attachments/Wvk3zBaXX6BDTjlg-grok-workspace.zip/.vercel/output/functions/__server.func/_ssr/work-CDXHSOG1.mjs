import { V as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Container, u as publishedProjects, v as breadcrumbJsonLd } from "./router-bk_2vDcH.mjs";
import { t as JsonLd } from "./json-ld-IR7igJk0.mjs";
import { t as CtaBand } from "./cta-band-DznpNq9S.mjs";
import { t as PageHeader } from "./page-header-DMPnpCTM.mjs";
import { t as ProjectRow } from "./project-row-CaCPCXKt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/work-CDXHSOG1.js
var import_jsx_runtime = require_jsx_runtime();
function WorkIndex() {
	const published = publishedProjects();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: breadcrumbJsonLd([{
				name: "Home",
				path: "/"
			}, {
				name: "Work",
				path: "/work"
			}]) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Work",
				title: "Selected work",
				description: "Client project content will be added here. Placeholders show how case studies will be presented — they are not invented clients."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, {
				className: "py-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: published.map((project, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectRow, {
						project,
						index: i,
						reverse: i % 2 === 1
					}, project.slug))
				})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, { title: "Have something similar in mind?" })
		]
	});
}
//#endregion
export { WorkIndex as component };
