//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BpL1AWqB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/ecosystem",
			"/privacy",
			"/review",
			"/terms",
			"/services/ai-solutions",
			"/services/automation",
			"/services/software-development",
			"/services/web-development",
			"/work/$slug",
			"/services/",
			"/work/"
		],
		preloads: ["/assets/index-BlPJcvn2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BlPJcvn2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-7_VccOw6.js",
			"/assets/cta-band-u9OfYBme.js",
			"/assets/json-ld-C27OzXSg.js",
			"/assets/status-chip-F4EHDY4s.js",
			"/assets/process-section-LRmcBg4K.js",
			"/assets/project-row-DefidB4r.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-z-vgjo4E.js",
			"/assets/cta-band-u9OfYBme.js",
			"/assets/page-header-BG_dNeDo.js",
			"/assets/json-ld-C27OzXSg.js"
		]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-b4f90xTY.js",
			"/assets/createServerFn-CdV5W4NM.js",
			"/assets/page-header-BG_dNeDo.js",
			"/assets/json-ld-C27OzXSg.js"
		]
	},
	"/ecosystem": {
		filePath: "/workspace/src/routes/ecosystem.tsx",
		children: void 0,
		preloads: [
			"/assets/ecosystem-TNmNMJE-.js",
			"/assets/cta-band-u9OfYBme.js",
			"/assets/page-header-BG_dNeDo.js",
			"/assets/json-ld-C27OzXSg.js",
			"/assets/status-chip-F4EHDY4s.js"
		]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-DwDg2hXY.js", "/assets/page-header-BG_dNeDo.js"]
	},
	"/review": {
		filePath: "/workspace/src/routes/review.tsx",
		children: void 0,
		preloads: [
			"/assets/review-SKvhKOya.js",
			"/assets/createServerFn-CdV5W4NM.js",
			"/assets/page-header-BG_dNeDo.js",
			"/assets/json-ld-C27OzXSg.js"
		]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-DJInaT_8.js", "/assets/page-header-BG_dNeDo.js"]
	},
	"/services/ai-solutions": {
		filePath: "/workspace/src/routes/services/ai-solutions.tsx",
		children: void 0,
		preloads: ["/assets/ai-solutions-3S6oMMrS.js", "/assets/service-page-cLwHx4iV.js"]
	},
	"/services/automation": {
		filePath: "/workspace/src/routes/services/automation.tsx",
		children: void 0,
		preloads: ["/assets/automation-DVbTJ60g.js", "/assets/service-page-cLwHx4iV.js"]
	},
	"/services/software-development": {
		filePath: "/workspace/src/routes/services/software-development.tsx",
		children: void 0,
		preloads: ["/assets/software-development-DXFWlLWw.js", "/assets/service-page-cLwHx4iV.js"]
	},
	"/services/web-development": {
		filePath: "/workspace/src/routes/services/web-development.tsx",
		children: void 0,
		preloads: ["/assets/web-development-D6peaKqL.js", "/assets/service-page-cLwHx4iV.js"]
	},
	"/work/$slug": {
		filePath: "/workspace/src/routes/work/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-o7-SHo7o.js",
			"/assets/json-ld-C27OzXSg.js",
			"/assets/status-chip-F4EHDY4s.js",
			"/assets/project-visual-Buj_odr3.js"
		]
	},
	"/services/": {
		filePath: "/workspace/src/routes/services/index.tsx",
		children: void 0,
		preloads: [
			"/assets/services-XLznvZUe.js",
			"/assets/cta-band-u9OfYBme.js",
			"/assets/page-header-BG_dNeDo.js",
			"/assets/json-ld-C27OzXSg.js",
			"/assets/process-section-LRmcBg4K.js",
			"/assets/faq-DiR1N_BZ.js"
		]
	},
	"/work/": {
		filePath: "/workspace/src/routes/work/index.tsx",
		children: void 0,
		preloads: [
			"/assets/work-C7M5v9Kf.js",
			"/assets/cta-band-u9OfYBme.js",
			"/assets/page-header-BG_dNeDo.js",
			"/assets/json-ld-C27OzXSg.js",
			"/assets/project-row-DefidB4r.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
